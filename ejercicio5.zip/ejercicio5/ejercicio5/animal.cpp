#include "animal.h"
using namespace std;

animal::animal(char no, char ti, char na, float p, bool s)
{
    //c

tipo = ti;
nacimiento = na;
peso = p;
salud = s;
} animal::animal(){}
void animal::setNo(char no){
nombre = no;
}
char animal::getNo(){
return nombre;}

void animal::setT(char ti){
tipo =ti;
}
char animal::getT(){
return tipo;

}
void animal::setNa(char na){
nacimiento = na;
}
char animal::getNa(){return nacimiento;}
void animal::setP(float pe){

peso = pe;}
float animal::getP(){return peso;}
void animal::setS(bool s){
salud = s;

}bool animal::getS(){return salud;}

void animal::print(){
cout<<"se ha creado el zoo"<<endl;

}
