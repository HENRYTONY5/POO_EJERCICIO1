#ifndef ZOO_H
#define ZOO_H


class zoo
{
    public:
        zoo();

    protected:

    private:
};

#endif // ZOO_H
