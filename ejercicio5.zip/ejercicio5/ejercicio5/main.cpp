#include <iostream>
#include "zoo.h"


using namespace std;

int main()
{
   zoo leon;
   char no,na,ti;
   float pe;
   bool s;
   cout << "ingrese su nombre, tipo, nacimiento del animal"<<endl;
   cin >> no;
   cin >>ti;
   cin >> na;

   cout << "ingrese su peso, salud (0 mal, sano 1)" << endl;
    cin >> pe;
    cin >> s;
leon.setZ(no,ti,na,pe,s);
    leon.alimentar(12,20);
    leon.print();

}
