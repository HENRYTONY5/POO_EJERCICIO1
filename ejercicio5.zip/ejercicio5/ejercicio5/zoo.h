#ifndef ZOO_H
#define ZOO_H
using namespace std;
#include "animal.h"
class zoo
{
     private:
        animal leon;
    public:
        zoo(){ cout<< "el zoo esta abierto " <<endl;}
        void setZ(char no, char ti, char nac, float p, bool s){
        leon.setNo(no);
        leon.setT(ti);
        leon.setNa(nac);
        leon.setP(p);
        leon.setS(s);

        }
        void print(){

        cout << "nombre: " << leon.getNo() << "tipo: " <<leon.getT() << " nfnac: "<< leon.getNa() << " peso: "<< leon.getP() << "salud: " << leon.getS()<<endl;

        }
        void alimentar(int h, int h1){
        cout<< " ingrese la ultima hora en la que comio el animal 1H-24H "<<endl;
        cin>>h;

        cout<< " ingrese la hora  1H-24H "<<endl;
        cin>>h1;
        if (h > h1){

               cout<< " el animal debe comer: "<<endl;
        }else cout<< " el animal no debe comer: "<<endl;
        }

    protected:


};

#endif // ZOO_H
