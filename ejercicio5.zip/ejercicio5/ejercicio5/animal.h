#ifndef ANIMAL_H
#define ANIMAL_H
#include <iostream>


class animal
{
    public:
      animal(char no, char ti,char na,float pe,bool s);
        animal();

        void setNo( char no);
        char getNo();
        void setT(char ti);
        char getT();
        void setNa(char na);
        char getNa();
        void setP(float p);
        float getP();
        void setS(bool s);
        bool getS();

        void print();

    protected:

    private:
         char nombre;
        char tipo;
        char nacimiento;
        float peso;
        bool salud;



};

#endif // ANIMAL_H
